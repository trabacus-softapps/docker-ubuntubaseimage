cChardet is high speed universal character encoding detector. - binding to charsetdetect.
This library is faster than chardet.


