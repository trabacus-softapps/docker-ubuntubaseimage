"""Auto-generated file, do not edit by hand. 54 metadata"""
from ..phonemetadata import NumberFormat

PHONE_ALT_FORMAT_54 = [NumberFormat(pattern='(9)(\\d{4})(\\d{3})(\\d{3})', format='\\1 \\2 \\3 \\4', leading_digits_pattern=['9[23]']), NumberFormat(pattern='(\\d{4})(\\d{3})(\\d{3})', format='\\1 \\2 \\3', leading_digits_pattern=['[23]'])]
