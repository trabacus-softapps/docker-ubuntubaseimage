"""Auto-generated file, do not edit by hand. 972 metadata"""
from ..phonemetadata import NumberFormat

PHONE_ALT_FORMAT_972 = [NumberFormat(pattern='([2-489])(\\d{3})(\\d{2})(\\d{2})', format='\\1-\\2-\\3-\\4', leading_digits_pattern=['[2-489]'])]
