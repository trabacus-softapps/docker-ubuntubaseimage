"""Auto-generated file, do not edit by hand. 856 metadata"""
from ..phonemetadata import NumberFormat

PHONE_ALT_FORMAT_856 = [NumberFormat(pattern='(20\\d)(\\d{3})(\\d{4})', format='\\1 \\2 \\3', leading_digits_pattern=['20']), NumberFormat(pattern='(20)(\\d{4})(\\d{4})', format='\\1 \\2 \\3', leading_digits_pattern=['20']), NumberFormat(pattern='(20)(\\d{8})', format='\\1 \\2', leading_digits_pattern=['20'])]
