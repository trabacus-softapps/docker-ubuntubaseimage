"""Auto-generated file, do not edit by hand. 39 metadata"""
from ..phonemetadata import NumberFormat

PHONE_ALT_FORMAT_39 = [NumberFormat(pattern='(0\\d{3})(\\d{2})(\\d{2})(\\d{2})', format='\\1 \\2 \\3 \\4', leading_digits_pattern=['0[13-57-9][2-46-8]']), NumberFormat(pattern='(0\\d{3})(\\d{2})(\\d{3})', format='\\1 \\2 \\3', leading_digits_pattern=['0[13-57-9][2-46-8]'])]
