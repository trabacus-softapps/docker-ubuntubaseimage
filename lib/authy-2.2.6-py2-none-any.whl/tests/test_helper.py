API_URL = "api-url"
API_KEY = "fake-key"

PHONE_NUMBER = '555-123-4567'
COUNTRY_CODE = '1'
API_USER_ID = 123

AUTH_ID_A = 14125
AUTH_ID_B = ''

NONCE = '1427849783.886085'
URL = 'https://api.authy.com/dashboard/json/application/webhooks'
PARAMS = {"b": "val|ue&2", "a": "value1"}

POST_REQ_SIGNATURE = 'UJRjviTdXFA0xu4duxW9BWVDRZGsmSUDd4RglmzcX4o='
GET_REQ_SIGNATURE = 'yjA/tsM6Rkxgww9wmZLxRWaouw21ZRsi7QIOdm7cEmA='
