# -*- coding: utf-8 -*-
# File generated from our OpenAPI spec
from stripe.sigma._scheduled_query_run import (
    ScheduledQueryRun as ScheduledQueryRun,
)
