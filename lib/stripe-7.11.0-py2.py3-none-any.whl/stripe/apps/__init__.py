# -*- coding: utf-8 -*-
# File generated from our OpenAPI spec
from stripe.apps._secret import Secret as Secret
