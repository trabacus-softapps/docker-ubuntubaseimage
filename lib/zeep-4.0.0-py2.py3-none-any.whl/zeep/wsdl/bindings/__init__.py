from .http import HttpGetBinding, HttpPostBinding  # noqa
from .soap import Soap11Binding, Soap12Binding  # noqa
