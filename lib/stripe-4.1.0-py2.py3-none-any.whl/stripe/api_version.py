# File generated from our OpenAPI spec


class _ApiVersion:
    CURRENT = "2022-08-01"
