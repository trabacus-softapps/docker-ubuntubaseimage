SOAPpy provides tools for building SOAP clients and servers.  For more information see https://github.com/kiorky/SOAPpy.git

==============================================
SOAPpy - Simple to use SOAP library for Python
==============================================

.. contents::

Disclaimer
==========
Please use `suds <https://pypi.python.org/pypi/suds>`_ rather than SOAPpy.
SOAPpy is old and clamsy.

Credits
========

Companies
---------
|makinacom|_

  * `Planet Makina Corpus <http://www.makina-corpus.org>`_
  * `Contact us <mailto:python@makina-corpus.org>`_

.. |makinacom| image:: http://depot.makina-corpus.org/public/logo.gif
.. _makinacom:  http://www.makina-corpus.com

Authors
------------

- Cayce Ullman <c_ullman@yahoo.com>
- Brian Matthews <blm@blmatthews.com>
- Gregory R. Warnes <Gregory.R.Warnes@Pfizer.com>
- Makina Corpus <python@makina-corpus.com>
- Mathieu Le Marec - Pasquet <kiorky@cryptelium.net>

Contributors
----------------
- Christopher Blunck <blunck2@gst.com>
- Brad Knotwell <b.knotwell@f5.com>
- Mark Bucciarelli <mark@hubcapconsulting.com> (ported WSDL client from ZSI)
- Ivan R. Judson     <judson@mcs.anl.gov> (Globus support)
- Kirk Strauser <kirk@daycos.com>
- Antonio Beamud Montero <antonio.beamud@linkend.com> (patches for integrating SOAPpy into Zope)
- And others.

Copyright (c) 20011 Makina Corpus
Copyright (c) 2002-2005, Pfizer, Inc.
Copyright (c) 2001, Cayce Ullman.
Copyright (c) 2001, Brian Matthews.
All rights reserved, see the file LICENSE for conditions of use.

INTRODUCTION
==============

The goal of the SOAPpy team is to provide a full-featured SOAP library
for Python that is very simple to use and that fully supports dynamic
interaction between clients and servers.


INCLUDED
--------
- General SOAP Parser based on sax.xml
- General SOAP Builder
- SOAP Proxy for RPC client code
- SOAP Server framework for RPC server code

FEATURES
--------
- Handles all SOAP 1.0 types
- Handles faults
- Allows namespace specification
- Allows SOAPAction specification
- Homogeneous typed arrays
- Supports multiple schemas
- Header support (mustUnderstand and actor)
- XML attribute support
- Multi-referencing support (Parser/Builder)
- Understands SOAP-ENC:root attribute
- Good interop, passes all client tests for Frontier, SOAP::LITE, SOAPRMI
- Encodings
- SSL clients (with Python compiled with OpenSSL support)
- SSL servers (with Python compiled with OpenSSL support and M2Crypto installed)
- Encodes XML tags per SOAP 1.2 name mangling specification (Gregory Warnes)
- Automatic stateful SOAP server support (Apache v2.x) (blunck2)
- WSDL client support
- WSDL server support

TODO (See RELEASE_INFO and CHANGELOG for recent changes)
----------------------------------------------------------
- Timeout on method calls
- Advanced arrays (sparse, multidimensional and partial)
- Attachments
- mod_python example
- medusa example
- Improved documentation

MANIFEST
--------
::

    Files

        README              This file
        RELEASE_NOTES       General information about each release
        ChangeLog           Detailed list of changes
        TODO                List of tasks that need to be done
        setup.py            Python installation control files
        SOAPpy.spec         RPM package control file

    Directories

        SOAPpy/            Source code for the package
        SOAPpy/wstools/    Source code for WSDL tools
        tests/             unit tests and examples
        validate/          interop client and servers
        bid/               N+I interop client and server
        contrib/           Contributed examples (also see test/)
        docs/              Documentation
        tools/             Misc tools useful for the SOAPpy developers
        zope/              Patches to Zope allowing it to provide SOAP services


INSTALLATION
============

USING GITHUB
------------

    You can install SOAPpy and its dependencies directly from GitHub using PIP:

        pip install -e "git+http://github.com/kiroky/SOAPpy.git@develop#egg=SOAPpy"

REQUIRED PACKAGES
------------------

    - wstools


OPTIONAL PACKAGES
-----------------

    - pyGlobus, optional support for Globus,
      <http://www-itg.lbl.gov/gtg/projects/pyGlobus/>

    - M2Crypto.SSL, optional support for server-side SSL
      <http://sandbox.rulemaker.net/ngps/m2/>

    - If Python is compiled with SSL support (Python 2.3 does so by
      default), client-side use of SSL is supported

INSTALLATION STEPS
------------------

    As of version 0.9.8 SOAPpy can be installed using the standard python
    package installation tools.

    To install:

      1) Unpack the distribution package:

         On Windows, use your favorite zip file uncompression tool.

         On Unix::

             $ tar -xvzf SOAPpy-$VERSION$.tar.gz

         If you have gnu tar, otherwise
            ::

             $ gzcat SOAPpy-$VERSION$.tar.gz | tar -xvf -

      2) Change into the source directory
         ::

                 cd SOAPpy-$VERSION$

      3) Compile the package::

                $ python setup.py build

      4) Install the package

         On Windows::

                $ python setup.py install

         On Unix install as the owner of the python directories
         (usally root)::

                $ su root
                Password: XXXXXX
                $ python setup.py install


DOCUMENTATION
=============
QUICK START
-----------

A simple "Hello World" http SOAP server::

        import SOAPpy
        def hello():
            return "Hello World"
        server = SOAPpy.SOAPServer(("localhost", 8080))
        server.registerFunction(hello)
        server.serve_forever()

And the corresponding client::

        import SOAPpy
        server = SOAPpy.SOAPProxy("http://localhost:8080/")
        print server.hello()

BASIC TUTORIAL
--------------
Mark Pilgrims _Dive Into Python, published in printed form by
Apress and online at at http://diveintopython.org provides a
nice tutorial for SOAPpy in Chapter 12, "SOAP Web Services".
See http://diveintopython.org/soap_web_services .

OTHER DOCUMENTATION
-------------------

For further information see the files in the docs/ directory.

Note that documentation is one of SOAPpy's current weak points.
Please help us out!


Support
============
Github: https://github.com/kiorky/SOAPpy
Issues: https://github.com/kiorky/SOAPpy/issues



CHANGELOG
=====================

0.12.22 (2014-06-20)
--------------------

- proper usage of config property inside objects. [Davorin Kunstelj]
- dump user defined types with handler functions (can be used to override dump
  of built-in types). [Davorin Kunstelj]


0.12.21 (2014-05-27)
--------------------

- Dispatching custom objects, slots supported.
  [Davorin Kunstelj]


0.12.20 (2014-05-15)
--------------------
- better version handling [kiorky]
- display summary on pypi [kiorky]
- non disclosed intermediate release to polish pypi output [kiorky]


0.12.6 (2014-05-15)
-------------------
- fix cve CVE Request ---- SOAPpy 0.12.5 Multiple Vulnerabilities -- LOL part
  [kiorky]
- fix cve CVE Request ---- SOAPpy 0.12.5 Multiple Vulnerabilities -- XXE part
  [kiorky]
- Remove dependency on fpconst.
- adding maptype  [Sandro Knauß]
- Support / (and other reserved characters) in the password. [Ionut Turturica]
- Client.HTTPWithTimeout: fixed constructor's docstring and comments -named the diferences
  with respect to the overriden method -fixed
  wrong reference to class in module 'httplib' -added documentation of param 't[German Larrain
- fixed module docstring location (all imports must be below them)[German Larrain]f
- fix error "Bad types (class java.math.BigInteger -> class java.lang.Integer)" - Clayton Caetano de Sousa]



0.12.5 (2011-08-01)
-------------------
- Fix for multi-dimensional arrays. [Ionut Turturica]
- Credits

0.12.3 (2011-02-21)
-------------------

- Fixed url


0.12.2 (2011-02-21)
-------------------

- Fixed url


0.12.1 (2011-02-21)
-------------------
- Forked intially from https://github.com/pelletier/SOAPpy
    - main interresting enhancements grabbed:

        - from __future__ imports must occur at the beginning of the file
        - try install requires

- Grabbed others changeset from  https://bitbucket.org/cmclaughlin/soappy-0.12.0/ (fpconst)
- Grabbed others changeset from  https://bitbucket.org/zeus/soappy (ssl key support)
- Depend directly on wstools not to bundle a duplicated version.
- Grabbed from original svn:

    - rpm spec file
    - tools/
    - zope/
    - bid/
    - .cvsignore files

- Make it proper packaged, specially toward setuptools.

Release 0.12.0 of SOAPpy
------------------------

This release primarily foces on bug fixes.  Primary changes:

- Fixes for bug reports that have accumulated over the last year

    [ 916265] "Arrays of unicode do not serialize correctly (patch included)"
    [ 918216] "Parsing faults in SOAPpy 0.11.3"
    [ 925077] "SOAPpy prints out SOAP fault" (even when Config.debug is off).
    [1001646] "SOAPpy stomps headers when sending multirefs"
    [1001646] "SOAPpy stomps headers when sending multirefs.
    [1064233] "Bug fixes for complex types"
    [1064248] "Bugs in _asdict() and _asarray() in Types.py"
    [1078051] "Arrays of complex types (doc/lit)"
    [1096971] "Parse error: missing HTTP header 'Content-length'"
    [1106450] "Floats are truncated to 10 digits, causing precision loss"
    [1122991] "error from SOAPpy/Client.py for content_length evaluation?"

- Fixes for 'rules' which allow control of the data types of *incoming* messages.
  As a consequence TCtest.py now passes all tests.

- WSDL support has been improving, due to work on the 'wstools'
  module which is shared between ZSI and SOAPpy.

- Some work has been done to improve documentation.


Release 0.11.6 of SOAPpy
------------------------

Changes to URLs and email addresses in documentation.


Release 0.11.5 of SOAPpy
------------------------

- Bug fixes

   - Fix string format error in fault handling


Release 0.11.4 of SOAPpy
------------------------

- Bug fixes

    - SOAPpy/Server.py: Check if header information contains SOAPAction
	  key before checking its value.

    - Fixes for generating SOAP from complexType arrays, contributed by
      antonio.beamud@linkend.com

    - Fixed bug that caused typedArrayTypes to lose their type
      information when rendered to SOAP and added corresponding
      test case.

- New Features

   - Enhancements to fault handling: The faultType Faultstring is now
     a non-variable string (i.e. no nsmethod in it) so that it can be
     programmatically checked.  In addition fault handlers can now be
     registered to handle specific types of faults.


   - SOAPpy/Server.py: Modified unregsiterObject function to take
     optional namespace/path args to be consistent with registerObject.

   - SOAPpy/Server.py: Added an unregisterObject function

   - Changes to allow SOAPBuilder so it can handle a 'raw' Python object.



Release 0.11.2 of SOAPpy
------------------------

- News:

   Ivan R. Judson has joined the SOAPpy team. He is focused on
   Globus support but is also responsible for a lot of other work for
   this release,

- Bug fixes:

   - Code in Types.py assumes nested scopes, so I added the proper import so
     this will work under python 2.2.x

   - Fixing namespace collision

   - Fixed handing of named arguments bug introduced in 0.11.1.

   - Fix memory leak when exceptions are raised.

   - Fix bug when content-length is not present in parsed SOAP message.

   - Fix bug #888345: Python 2.3 boolean type serialized as int

   - Fix bug #875977: no escaping of bad tagnames for NoneTypes


- New features:

   - Improved Globus support and documentation.  Thanks Ivan!

   - Added context handling

   - Changed the use of SOAPAction, it used to default to setting it
     to "", now it defaults to setting it to the method (not the
     nsmethod). There is a clause in Server.py that catches 'old style'
     SOAPActions (aka "") and sets them to the method. When this is
     confirmed to be what everyone wants and we decide it's alright to
     (possibly) break client/server interop, we can take the clause out
     of Server.py and just handle SOAPActions of "" as a possible
     error/warning.

   - Additional test code.

   - Raise a SOAPException instead of returning a SOAPpy.faultType
     when a SOAP Fault is encountered and simplify_objects is enabled.


Release 0.11.1 of SOAPpy
------------------------

- Bug fixes:

   - Fixed bug [ 792258 ] "SOAPBuilder.SOAPBuilder.dump can catch
     wrong exceptions" in SOAPBuilder.dump() submitted by Greg Chapman
     (glchapman).

   - Changes suggested by Richard Au (richardau) to fix ssl support.
     See bug report [ 752882 ] "SSL SOAP Server no longer working."

   - Remove call to gentag from 'dump' and add to 'dump_float', per
     bug report [ 792600 ] "SOAPBuilder.SOAPBuilder.dump possibly should
     not call gentag" by Greg Chapman (glchapman).

   - Add a tests for handling of nil="true" and nil="false".  This
     fixes bug [ pywebsvcs-Bugs-858168 ] 'xsi:nil="true" causes
     exception' reported by Robert Zimmermann (robertzett):

- testClient1.py now works properly.  It had been failing to start the
  server thread on the second unit test.  It turned out that the
  variable 'quit' needed to be reset to zero after the SOAP server
  thread for the first unit test exited.  With the solution of this
  problem testClient1 can now be extended to run unit tests of both
  client and server components.

- Added 'strict' option to the WSDL class. If strict is true, a
  RuntimeException will be raised if an unrecogned message is recieved.
  If strict is false, a warning will be printed to the console, the
  message type will be added to the WSDL schema, and processing will
  continue.  This is in response to the second half of bug report [
  817331 ] "Some WSDL.py changes", submitted by Rudolf Ruland.


Release 0.11.0 of SOAPpy
------------------------

- New/Changed configuration settings:

  - Config.simplify_objects=1 now converts all SOAPpy objects into basic
    Python types (list, dictionary, tuple, double, float, etc.).  By default,
    Config.simplify_objects=0 for backward compatibility.

  - Config.dict_encoding='ascii' converts the keys of dictionaries
    (e.g. created when Config.simplify_objects=1) to ascii == plain python
    strings instead of unicode strings.  This variable can be set to any
    encoding known to string.encode().

  - Config.strict_range=1 forces the SOAP parsing routines to perform
    range checks on recieved SOAP float and double objects.  When
    Config.strict_range=0, the default, parsing does not perform range
    checking (except for detecting overflows, which always occurs).  In
    either case, range checking is performed when
    generating SOAP float and double objects.

- Fixes for WSDLProxy.

- Scripts in the test/ directory

  - Verbose debugging messages have been turned off..

  - SOAPtest.py now functions when Config.simplify_objects=1

  - SOAPtest.py now sets Config.strict_range=1 so that range
    checks are be properly tested.

  - New README file listing what test scripts fail and why.

- Initial support for Globus via pyGlobus contributed by Ivan
  R. Judson <judson@mcs.anl.gov>.

Release 0.10.4 of SOAPpy
------------------------

Dramatic performance improvements for large data transfers.

Release 0.10.1 of SOAPpy
------------------------

only minor changes

1) Code now uses a single file to store version number

2) Client and server now report 'SOAPpy' as the server/user-agent.

3) All test scripts now use the local SOAPpy source instead of the
   globally installed version.

Release 0.10.0 of SOAPpy
------------------------

Enhancements:

1) The new name handling mechanism has been enabled by default.

   The primary purpose of this release is to allow users to test this
   to see if it causes problems.  Please take the time to do so.  If
   there are no problems reported by April 15, 2003, 0.9.9 will be
   released with this feature enabled by default.

   Note that running a client under an old release of SOAPpy and a
   server under this release will be likely to generate errors due to
   the different name handling mechanisms.

2) MS-Windows systems should now be fully supported.

   This required implementing a new module, ieee754, which provides
   functions for detecting and generating IEEE 754 special floating
   point values (+Inf, -Inf, NaN) which are not properly handled by
   the Windows implementation of the float() function.

3) Code reorganization: The huge file SOAPpy/SOAP.py (4,122 lines,
   131K) has been split into 10 separate files. In addition code
   shared with ZSI has been moved into a separate subdirectory and a
   separate CVS module.

4) Fixed bug 678239 which caused loss of namespace information in the
   client.

5) Mark Bucciarelli's <mark@hubcapconsulting.com> has ported client
   support for WSDL from ZSI, as well as providing a mechanism for
   SOAPpy servers to provide WSDL on properly structured .GET
   requests.

6) Added ThreadingSOAPServer which inherits from ThreadingTCPServer
   server so that multiple clients will be automatically multiplexed.


VERSION 0.10.4
--------------

- Integrated a simple patch submitted by Erik Westra that dramatically
  improves parser performance.

- WSDL tools now uses m2crypto for SSL if it's installed.

- Various other WSDL changes.

VERSION 0.10.3
--------------

- Removed import of obsoleted ieee753.py.  Now use the fpconst module
  proposed by PEP 754, available from
  <http://research.warnes.net/Zope/projects/fpconst/>

- SOAPpy should no longer depend on pyXML.

VERSION 0.10.2
--------------

- Fixed client support for basic authentication

- Fixed import error in Client.py

- Improved Client parsing of namespaces to support stateful SOAP servers.

VERSION 0.10.1
--------------

- Modified setup.py, Server.py, and Client.py to obtain SOAPpy version
  number from a new file, version.py.

- SOAP server/user-agent is now to 'SOAPpy' instead of 'SOAP.py'.

- Added ident string containing CVS version to all files that were
  lacking this.

VERSION 0.10.0
--------------

CHANGES SINCE VERSION 0.9.9-pre5

- Major Change: The huge file SOAPpy/SOAP.py (4,122 lines, 131K) has
  been split into 10 separate files::

	Client.py	NS.py		SOAPBuilder.py	Utilities.py
	Config.py	Parser.py	Server.py
	Errors.py	SOAP.py		Types.py

  This should ease navigation and maintenance.

- A new CVS module 'wstools' was created to hold code which is used by
  both ZSI and SOAPpy.  While this module is stored separately in CVS,
  it will be distributed as an integral part of both ZSI and SOAPpy,
  and will be included as an 'internal' module by both.  In the SOAPpy
  source, it lives in the directory SOAPpy/wstools.

- The files XMLname.py, ieee754.py, have been moved into SOAPpy/wstools.

- Added TODO file

- Fix bug in getNS that caused loss of namespace by using better
  pattern matching to find the namespace in the SOAP message.  Fixes bug
  678239

- Added Mark Bucciarelli's <mark@hubcapconsulting.com> patch to
  provide wsdl code on properly structured .GET requests to the server.

- Added client support for WSDL, ported from ZSI by Mark Bucciarelli
  <mark@hubcapconsulting.com>

- Added ThreadingSOAPServer which inherits from ThreadingTCPServer
  server so that muliple clients will be automatically multiplexed.

- Removed some files from /test for services that no longer exist.


CHANGES SINCE VERSION 0.9.9-pre4
--------------------------------

- Added client support for WSDL, ported from ZSI by Mark Bucciarelli
  <mark@hubcapconsulting.com>.

CHANGES SINCE VERSION 0.9.9-pre3
--------------------------------

- Code shared between SOAPpy and ZSI now lives in
  SOAPpy/SOAPpy/wstools and is stored in a separate CVS package.  This
  will allow ZSI and SOAPpy to keep these files synchronized.

CHANGES SINCE VERSION 0.9.9-pre2
--------------------------------

- Fixed trivial compilation bug on Win32: Only define
  SOAPUnixSocketServer if the Unix domain sockets are supported

CHANGES SINCE VERSION 0.9.9-pre1
--------------------------------

- Added request for nested scopes, should now work properly in python
  2.1 with named argument calls.

- Fixed bug caused by omission of the ieee754 module from __init__.py.

- SOAPpy now provides a SOAPUnixSocketServer class, which uses a unix
  domain socket instead of a network TCP/IP socket for communication. A
  corresponding client will be provided in the future.  [This class
  has not yet been tested.]

CHANGES SINCE VERSION 0.9.8
---------------------------

- IEEE 754 floating point specials (Inf, -Inf, NaN) should now be
  properly and consistently handled on all platforms.

  Added code to explicitly check for and handle IEEE 754 floating
  point specials (Inf, -Inf, NaN). This replaces an ugly hack for
  systems whose python float() doesn't understand the strings "Inf",
  "NaN", etc.  Floating point specials should now be properly handled
  on all operating systems.

  ***SOAPpy should now work properly on all versions of Microsoft Windows.***

  A new module, ieee754 contains the functions required to detect and
  create NaN, Inf, and -Inf values.  This module should be usable in
  other contexts.

- *** The new argument handling method (via SOAPpy.SOAP.Config.specialArgs=1)
  is now enabled by default.***

- Changed all references to actzero.com in SOAP.py to pywebscvs.sf.net.

- Fixed a bug where lists included as parameters to SOAP method calls
  were being incorrectly named 'Results' even when another name was
  given.

CHANGES SINCE VERSION 0.9.7
---------------------------

- Modified structure to allow installation using Python distutils
  (i.e. setup.py).  Access to the SOAPpy library now requires:
  from SOAPpy import SOAP

- I (Gregory R. Warnes) have implemented an experimental and
  non-standard method of handling named and unnamed arguments.  This
  mechanism is enabled in SOAPpy by setting
  SOAPpy.SOAP.Config.specialArgs=1.

  When enabled, parameters with names of the form _#### (i.e.,
  matching the regexp "^_[0-9]+") are assumed to be unnamed parameters
  and are passed to the method in numeric order.  All other parameters
  are assumed to be named and are passed using the xml tag id as the
  parameter name.  Outgoing SOAP method calls now always generate
  names in this way--whether or not specialArgs is enabled--instead of
  using the pattern v#####.

  See the file README.MethodParameterNaming for more details.

- Added noroot parameter to the SOAPBuilder and SOAPProxy objects
  in order to provide compatibility with an older version of
  EasySOAP (v0.2) that balked if the SOAP-ENC:root parameter was
  included.(Brad Knotwell)

- Added support for namespace-rewriting (used by Apache v2.x SOAP server for
  error conditions as well as stateful communication) (Christopher Blunck)

- Added string <-> str conversion for array types (Python 2.2+)
  (Christopher Blunck)

- Added convenience method (invoke) to SOAPProxy that calls __call (not sure
  if it is necessary - feel free to remove if you want) (Christopher Blunck)

- Python 'float' are equivalent to SOAP 'double'.  Modified dump_float
  and dump_list to use SOAP type string 'double'
  appropriately. (Gregory R. Warnes)

- Add basic authentication (Brad Knotwell)

- Fixes to enable proper handling of SOAP faults by the client:
  - Fixed test of whether message content is text/xml when recieving a fault.
  - Added __call__ method to exception classes to match the current API.
  - The faultType.__repr__() method now print details if present
  (Gregory R. Warnes)

- Added XMLnam.py which provides toXMLname() and fromXMLname() for
  properly encoding xml tag names per the SOAP 2.1 (draft)
  specification. (Gregory R. Warnes)

- Added calls to toXMLname() and fromXMLname() so that tags names are
  properly encoded.  This resolves bug [ 548785 ] 'Error passing dict
  keys containing space.'  (Gregory R. Warnes)

- Added code to cgi encode contents of tags when they are not a
  recognized type.  Fixes bug [ 549551 ] 'Error when passing
  non-standard types'. (Gregory R. Warnes)

- Added __init__.py, so that SOAPpy can be used like a standard python
  module. (Gregory R. Warnes)


VERSION 0.9.7 (6/27/01)
-----------------------

- Fixed the unamed ordered parameters bug
- Added the ability to specify a http_proxy
- Added a patch provided by Tim MiddelKoop to allow printing of proxy objects
- Added the contrib directory and included a medusa implementation of a
  SOAP.py server by Ng Pheng Siong


VERSION 0.9.6 (6/08/01)
-----------------------

- The date and time types now check their initial values when the type
  is created, not when the data is marshalled.
- The date and time types are now parsed and returned as tuples (for
  multi-element types) or scalars (for single element types) in UTC and thus
  can represent the entire range of SOAP dates.
- If an element doesn't have a type but has a name with a namespace, the
  name is tried as the type.
- Untyped compound types with more than one element and all the elements
  the same name are turned into an array when parsing.
- When parsing a structType, elements with the same name are placed in a
  list instead of saving just the last one. _getItemsAsList can be used to
  get an element of a structure as a list, whether there was one or many
  occurances of the item.
- Added schemaNamespace, schemaNamespaceURI, and namespaceStyle
  configuration options. namespaceStyle takes one of 1999, 2000, or 2001,
  and sets typesNamespace, typesNamespaceURI, schemaNamespace, and
  schemaNamespaceURI.
- Normalized the type class names, replacing Compound with compoundType,
  Struct with structType, Header with headerType, Body with bodyType, Array
  with arrayType, TypedArray with typedArrayType, Fault with faultType, and
  urType with anyType.
- Attributes now appear on an element itself instead of the element's
  parent. For elements parsed to builtin python types, the attributes are
  stored in a dictionary keyed by the element's python id. The dictionary
  is in the Context object, can be returned from parseSOAP*, and can be
  returned from method calls if the returnAllAttrs configuration option
  is set.
- isinstance is used to check for a class, so classes can be subtyped.
- An encoding of None can be specified to not include encoding information.
- Problems with the SOAPProxy URL are now reported when the SOAPProxy
  instance is created instead of when the first method call is made.
- The Binary, Boolean and DateTime types have been removed in favor of
  binaryType, booleanType, and dateTimeType.


VERSION 0.9.5 (5/16/01)
-----------------------

- Should parse and build all 1999, 2000, 2001, and SOAP-ENC datatypes.
- Initial handling of multi-dimensional, partial, and sparse arrays.
- Supports SSL clients (if Python built with OpenSSL).
- Supports SSL servers (if M2Crypto installed).
- Applies defaults to SOAPproxy URLs (nice for command-line tools).
- Added the _SOAPContext object, gives registered server functions more info
  about the current call.
- Now assumes that any type that isn't in a schema could be a struct.
- Added the Config object, now config options can be set globally or on an
  individual call level.
- Deprecated the DateTime, Binary and Boolean types, should now
  use dateTimeType, binaryType and booleanType.
- Includes N+I interop suite.
- Various bug fixes and improvements.

VERSION 0.9 (5/01/01)
-----------------------

- The Envelope now just contains definitions for namespaces actually used
  (Builder)
- Namespace definitions are inherited by children but not siblings (Builder)
- Further improved multi-reference parsing -- it handles circular references
  (Parser)
- Added support for building recursive and circular types using references
  (Builder)
- More types
- Proper handling of overflow and underflow integral and floating point
  types (Parser)
- More interop
- Various bug fixes and improvements

VERSION 0.8.5 (4/25/01)
-----------------------

- buildSOAP, SOAPProxy, SOAPServer now taking encoding argument
- Much improved multi-referencing (Parser)
- Added base64 and dateTime to interop suite
- Various bug fixes

VERSION 0.8 (4/23/01)
-----------------------

- Added more types
- Early multi-referencing support (Parser)
- Reorganized the parser, much cleaner now
- Preserve whitepsace in strings (per the standard)
- Full XML attribute support (Parser/Builder)
- Object (de)serialization now maintains element order
- Fixed the zero-length array problem
- Made indentation uniform (spaces not tabs)
- Made Header and Body work more like real structs
- Changed the parseSOAP api, now returns the body structure,
  instead of a list of body elements
- Changed the soapaction and namespaces for the interop server
- New silabclient options
- Initial encoding support

VERSION 0.7 (4/19/01)
-----------------------

- Fixed a bug that caused nothing to work with Python 2.1
- Float work arounds for WIN32 (others?)
- DateTime parsing for WIN32
- Beginnings of XML attribute support
- Better interop

VERSION 0.6 (4/18/01)
-----------------------

- Fixed numerous bugs (dateTime, float precision, Response Element, null
  strings)
- Added more types
- Homogeneous typed arrays
- Added support for more schemas
- Early Header support and mustUnderstand and actor
- Added interop suite
- Passes validator
- Interop greatly improved, passes all client tests for Frontier,
  SOAP::LITE.

VERSION 0.5 (4/17/01)
-----------------------

- Initial public release




